using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace portfolio.Views.Projects.Courses
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
